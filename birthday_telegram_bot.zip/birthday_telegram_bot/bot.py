import os
import asyncio
import logging
from datetime import datetime
from zoneinfo import ZoneInfo

import aiosqlite
from aiogram import Bot, Dispatcher, Router, F
from aiogram.filters import Command
from aiogram.types import Message
from apscheduler.schedulers.asyncio import AsyncIOScheduler

TOKEN = os.getenv("BOT_TOKEN", "")
CHAT_ID = os.getenv("CHAT_ID", "")
TIMEZONE = os.getenv("TIMEZONE", "Europe/Vienna")
DB_PATH = os.getenv("DB_PATH", "birthdays.db")

router = Router()

INITIAL_BIRTHDAYS = [
    ("09-18", "Косенко Ульяна"),
    ("09-24", "Стрельцова Дарья"),
    ("10-01", "Каряченец Дарья"),
    ("10-21", "Пронина Александра"),
    ("10-23", "Чегодаева Инга"),
    ("10-23", "Семёнова Мария"),
    ("11-16", "Дедова Екатерина"),
    ("11-24", "Монахова Жанна"),
    ("11-26", "Валова Полина"),
    ("12-15", "Ярец Евгения"),
    ("12-20", "Молостова Клара"),
    ("03-02", "Пряхина Елена"),
    ("03-17", "Ярославцева Мария"),
    ("03-17", "Джурмий Надежда"),
    ("04-05", "Шахова Ксения"),
    ("05-04", "Щетинина Елизавета"),
    ("05-13", "Дегасюк Анастасия"),
    ("05-27", "Трусова Варвара"),
    ("06-05", "Сухорукова Елизавета"),
    ("07-22", "Смирнова Мария"),
    ("08-04", "Сулейманова София"),
]

MONTHS = {
    1: "Январь", 2: "Февраль", 3: "Март", 4: "Апрель",
    5: "Май", 6: "Июнь", 7: "Июль", 8: "Август",
    9: "Сентябрь", 10: "Октябрь", 11: "Ноябрь", 12: "Декабрь",
}

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS birthdays (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                month_day TEXT NOT NULL,
                name TEXT NOT NULL,
                UNIQUE(month_day, name)
            )
        """)
        for month_day, name in INITIAL_BIRTHDAYS:
            await db.execute(
                "INSERT OR IGNORE INTO birthdays(month_day, name) VALUES (?, ?)",
                (month_day, name),
            )
        await db.commit()

async def get_today():
    now = datetime.now(ZoneInfo(TIMEZONE))
    return now.strftime("%m-%d"), now.strftime("%d.%m")

async def birthdays_for(month_day):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT name FROM birthdays WHERE month_day=? ORDER BY name",
            (month_day,),
        )
        rows = await cur.fetchall()
    return [r[0] for r in rows]

async def all_birthdays():
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT month_day, name FROM birthdays ORDER BY substr(month_day,1,2), substr(month_day,4,2), name"
        )
        return await cur.fetchall()

async def is_admin(message: Message):
    member = await message.bot.get_chat_member(message.chat.id, message.from_user.id)
    return member.status in ("administrator", "creator")

@router.message(Command("start"))
async def start(message: Message):
    await message.answer(
        "🎂 Привет! Я бот дней рождения вашей группы.\n\n"
        "Команды:\n"
        "/list — список дней рождения\n"
        "/today — кто празднует сегодня\n"
        "/add ДД.ММ Имя Фамилия — добавить себя\n"
        "/remove ДД.ММ Имя Фамилия — удалить запись\n"
        "/help — помощь\n\n"
        "Администраторы группы могут управлять любыми записями."
    )

@router.message(Command("help"))
async def help_cmd(message: Message):
    await start(message)

@router.message(Command("today"))
async def today(message: Message):
    month_day, date_text = await get_today()
    names = await birthdays_for(month_day)
    if not names:
        await message.answer(f"Сегодня ({date_text}) именинников нет 🎈")
    elif len(names) == 1:
        await message.answer(
            f"🎉 Сегодня день рождения у {names[0]}!\n"
            "Желаем счастья, успехов, исполнения желаний и отличного настроения! 🥳🎂"
        )
    else:
        joined = "\n".join(f"• {n}" for n in names)
        await message.answer(
            f"🎉 Сегодня ({date_text}) день рождения у:\n{joined}\n\n"
            "Поздравляем! 🥳🎂 Желаем счастья, успехов и отличного настроения!"
        )

@router.message(Command("list"))
async def list_cmd(message: Message):
    rows = await all_birthdays()
    grouped = {}
    for md, name in rows:
        m, d = map(int, md.split("-"))
        grouped.setdefault(m, []).append((d, name))

    lines = ["🎂 Дни рождения нашей группы\n"]
    for m in range(1, 13):
        if m not in grouped:
            continue
        lines.append(f"{MONTHS[m]}:")
        by_day = {}
        for d, name in grouped[m]:
            by_day.setdefault(d, []).append(name)
        for d in sorted(by_day):
            lines.append(f"{d} — {', '.join(by_day[d])}")
        lines.append("")
    await message.answer("\n".join(lines).strip())

def parse_birth_command(text):
    parts = text.split(maxsplit=2)
    if len(parts) < 3:
        return None, None
    date_text, name = parts[1], parts[2].strip()
    try:
        dt = datetime.strptime(date_text, "%d.%m")
        return dt.strftime("%m-%d"), name
    except ValueError:
        return None, None

@router.message(Command("add"))
async def add_cmd(message: Message):
    md, name = parse_birth_command(message.text or "")
    if not md or not name:
        await message.answer("Формат: /add ДД.ММ Имя Фамилия\nНапример: /add 18.09 Иван Иванов")
        return
    async with aiosqlite.connect(DB_PATH) as db:
        try:
            await db.execute(
                "INSERT INTO birthdays(month_day,name) VALUES (?,?)", (md, name)
            )
            await db.commit()
        except aiosqlite.IntegrityError:
            await message.answer("Такая запись уже есть.")
            return
    await message.answer(f"✅ Добавил: {name} — {datetime.strptime(md, '%m-%d').strftime('%d.%m')}")

@router.message(Command("remove"))
async def remove_cmd(message: Message):
    md, name = parse_birth_command(message.text or "")
    if not md or not name:
        await message.answer("Формат: /remove ДД.ММ Имя Фамилия")
        return

    admin = await is_admin(message)
    # Обычный участник может удалить только запись с точным именем, но команда
    # специально оставлена простой; для группового использования лучше проверять
    # Telegram username/ID в отдельной версии.
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "DELETE FROM birthdays WHERE month_day=? AND name=?", (md, name)
        )
        await db.commit()
        deleted = cur.rowcount

    if deleted:
        await message.answer(f"🗑 Удалил запись: {name}")
    else:
        await message.answer("Не нашёл такую запись.")

async def send_daily_birthdays(bot: Bot):
    if not CHAT_ID:
        logging.warning("CHAT_ID не задан — ежедневное поздравление пропущено.")
        return
    month_day, _ = await get_today()
    names = await birthdays_for(month_day)
    if not names:
        return
    if len(names) == 1:
        text = (
            f"🎉 Сегодня день рождения у {names[0]}!\n\n"
            "Желаем счастья, здоровья, успехов в учёбе, "
            "исполнения желаний и отличного настроения! 🥳🎂"
        )
    else:
        joined = "\n".join(f"• {n}" for n in names)
        text = (
            "🎉 Сегодня день рождения у:\n\n"
            f"{joined}\n\n"
            "Поздравляем всех именинников! 🥳🎂\n"
            "Желаем счастья, успехов, исполнения желаний и отличного настроения!"
        )
    await bot.send_message(chat_id=CHAT_ID, text=text)

async def main():
    if not TOKEN:
        raise RuntimeError("Не задан BOT_TOKEN.")
    logging.basicConfig(level=logging.INFO)
    await init_db()

    bot = Bot(TOKEN)
    dp = Dispatcher()
    dp.include_router(router)

    scheduler = AsyncIOScheduler(timezone=TIMEZONE)
    scheduler.add_job(send_daily_birthdays, "cron", hour=9, minute=0, args=[bot])
    scheduler.start()

    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
